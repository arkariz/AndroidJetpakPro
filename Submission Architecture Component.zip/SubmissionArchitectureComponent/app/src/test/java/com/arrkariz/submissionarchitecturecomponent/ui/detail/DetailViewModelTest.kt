package com.arrkariz.submissionarchitecturecomponent.ui.detail

import org.junit.Test

import org.junit.Assert.*
import org.junit.Before

class DetailViewModelTest {
    lateinit var viewModel: DetailViewModel

    @Before
    fun setup(){
        viewModel = DetailViewModel()
    }

    @Test
    fun getContent() {
        val contentId = "m01"
        val genre = "Drama, Music, Romace"

        viewModel.setSelectedContent(contentId)

        val content = viewModel.getContent()

        assertNotNull(content)
        assertEquals(contentId, content.contentId)
        assertEquals(genre, content.genre)
    }
}