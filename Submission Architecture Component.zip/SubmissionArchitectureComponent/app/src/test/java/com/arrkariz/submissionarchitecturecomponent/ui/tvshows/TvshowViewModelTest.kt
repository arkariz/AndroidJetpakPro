package com.arrkariz.submissionarchitecturecomponent.ui.tvshows

import com.arrkariz.submissionarchitecturecomponent.ui.movies.MovieViewModel
import org.junit.Test

import org.junit.Assert.*
import org.junit.Before

class TvshowViewModelTest {

    lateinit var viewModel: TvshowViewModel

    @Before
    fun setUp(){
        viewModel = TvshowViewModel()
    }

    @Test
    fun getTvshow() {
        val tvshow = viewModel.getTvshow()
        assertNotNull(tvshow)
        assertEquals(10, tvshow.size)
    }
}