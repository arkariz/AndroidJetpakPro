package com.arrkariz.submissionarchitecturecomponent.ui.detail

import androidx.lifecycle.ViewModel
import com.arrkariz.submissionarchitecturecomponent.entity.DetailEntity
import com.arrkariz.submissionarchitecturecomponent.utils.ContentDetail

class DetailViewModel: ViewModel() {
    private lateinit var contentId: String

    fun setSelectedContent(contentId: String) {
        this.contentId = contentId
    }

    fun getContent(): DetailEntity {
        lateinit var content: DetailEntity
        val entities = ContentDetail.setDetail()
        for (entity in entities) {
            if (entity.contentId == contentId) {
                content = entity
            }
        }
        return content
    }
}