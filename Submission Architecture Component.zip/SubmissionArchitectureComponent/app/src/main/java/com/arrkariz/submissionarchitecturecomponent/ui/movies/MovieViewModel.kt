package com.arrkariz.submissionarchitecturecomponent.ui.movies

import androidx.lifecycle.ViewModel
import com.arrkariz.submissionarchitecturecomponent.entity.MovieEntity
import com.arrkariz.submissionarchitecturecomponent.utils.ResourceData

class MovieViewModel: ViewModel() {
    fun getMovie(): List<MovieEntity> = ResourceData.setMovies()
}