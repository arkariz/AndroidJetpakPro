package com.arrkariz.submissionarchitecturecomponent.entity

data class DetailEntity(
    var contentId: String,
    var contentRating: String,
    var duration: String,
    var genre: String,
    var poster: Int
)
