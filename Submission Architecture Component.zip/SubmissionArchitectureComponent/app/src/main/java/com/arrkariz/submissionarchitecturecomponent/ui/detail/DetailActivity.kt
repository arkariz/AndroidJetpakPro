package com.arrkariz.submissionarchitecturecomponent.ui.detail

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.ViewModelProvider
import com.arrkariz.submissionarchitecturecomponent.databinding.ActivityDetailBinding
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.bumptech.glide.request.RequestOptions

class DetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailBinding

    companion object{
        const val EXTRA_ID = "extra_id"
        const val EXTRA_TITLE = "extra_title"
        const val EXTRA_RATING = "extra_rating"
        const val EXTRA_DESC = "extra_desc"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val viewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory())[DetailViewModel::class.java]
        val contentId = intent.getStringExtra(EXTRA_ID).toString()

        binding.apply {
            val title = intent.getStringExtra(EXTRA_TITLE)
            val rating = intent.getIntExtra(EXTRA_RATING,0)
            val desc = intent.getStringExtra(EXTRA_DESC)

            tvTitle.text = title
            tvRatingStar.text = rating.toString()
            tvDesc.text = desc.toString()
        }

        viewModel.setSelectedContent(contentId)
        val content = viewModel.getContent()
                binding.apply {
                    tvContentRating.text = content.contentRating
                    tvDuration.text = content.duration
                    tvGenre.text = content.genre

                    Glide.with(this@DetailActivity)
                            .load(content.poster)
                            .apply(RequestOptions().override(55, 55))
                            .transition(DrawableTransitionOptions.withCrossFade())
                            .into(ivPoster)
                }


    }
}