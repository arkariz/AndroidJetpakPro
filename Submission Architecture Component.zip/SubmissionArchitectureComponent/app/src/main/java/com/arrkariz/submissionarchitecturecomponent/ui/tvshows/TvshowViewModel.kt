package com.arrkariz.submissionarchitecturecomponent.ui.tvshows

import androidx.lifecycle.ViewModel
import com.arrkariz.submissionarchitecturecomponent.entity.DetailEntity
import com.arrkariz.submissionarchitecturecomponent.entity.MovieEntity
import com.arrkariz.submissionarchitecturecomponent.utils.ContentDetail
import com.arrkariz.submissionarchitecturecomponent.utils.ResourceData


class TvshowViewModel: ViewModel() {
    fun getTvshow(): List<MovieEntity> = ResourceData.setTvshow()
}