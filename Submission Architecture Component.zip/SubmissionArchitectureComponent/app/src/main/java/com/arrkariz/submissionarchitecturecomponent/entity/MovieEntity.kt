package com.arrkariz.submissionarchitecturecomponent.entity

data class MovieEntity(
    var movieId: String,
    var title: String,
    var desc: String,
    var rating: Int,
    var imagePath: Int
)
