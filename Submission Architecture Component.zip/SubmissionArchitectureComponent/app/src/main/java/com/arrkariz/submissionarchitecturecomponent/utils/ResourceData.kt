package com.arrkariz.submissionarchitecturecomponent.utils

import com.arrkariz.submissionarchitecturecomponent.R
import com.arrkariz.submissionarchitecturecomponent.entity.DetailEntity
import com.arrkariz.submissionarchitecturecomponent.entity.MovieEntity

object ResourceData {
    fun setMovies(): List<MovieEntity> {

        val movies = ArrayList<MovieEntity>()

        movies.add(MovieEntity(
                "m01",
                "A Star Is Born",
                "Seasoned musician Jackson Maine \n" +
                        "(Bradley Cooper) discovers-and falls \n" +
                        "in love with-struggling artist Ally (Gaga). \n" +
                        "She has just about given up on her \n" +
                        "dream to make it big as a singer \n" +
                        "until Jack coaxes her into the spotlight. \n" +
                        "But even as Ally's career takes off, \n" +
                        "the personal side of their relationship \n" +
                        "is breaking down, as Jack fights \n" +
                        "an ongoing battle with his own \n" +
                        "internal demons.",
                5,
                R.drawable.poster_a_start_is_born
            )
        )

        movies.add(MovieEntity(
                "m02",
                "Alita: Battle Angel",
                "Alita is a creation from an age of despair. Found by the mysterious Dr. Ido while trolling for cyborg parts, Alita becomes a lethal, dangerous being. She cannot remember who she is, or where she came from. But to Dr. Ido, the truth is all too clear. She is the one being who can break the cycle of death and destruction left behind from Tiphares. But to accomplish her true purpose, she must fight and kill. And that is where Alita's true significance comes to bear. She is an angel from heaven. She is an angel of death",
                5,
                R.drawable.poster_alita
        ))

        movies.add(MovieEntity(
                "m03",
                "Aquaman",
                "Born upon the shores of the surface world, Arthur Curry (Jason Momoa) discovers that he is only half human, with the other half of his blood being of Atlanteean descent, thus making him the rightful heir to the throne of the undersea kingdom of Atlantis. However, Arthur learns that Atlantis is being ruled by his malicious half-brother Orm (Patrick Wilson), who seeks to unite the seven underwater kingdoms and wage war upon the surface. With aid from Nuidis Vulko (Willem Dafoe) and the gorgeous Mera (Amber Heard), Arthur must discover the full potential of his true destiny and become Aquaman in order to save Atlantis and the surface from Orm's evil plot.",
                5,
                R.drawable.poster_aquaman
        ))

        movies.add(MovieEntity(
                "m04",
                "Bohemian Rhapsody",
                "Bohemian Rhapsody is a foot-stomping celebration of Queen, their music and their extraordinary lead singer Freddie Mercury. Freddie defied stereotypes and shattered convention to become one of the most beloved entertainers on the planet. The film traces the meteoric rise of the band through their iconic songs and revolutionary sound. They reach unparalleled success, but in an unexpected turn Freddie, surrounded by darker influences, shuns Queen in pursuit of his solo career.",
                5,
                R.drawable.poster_bohemian
        ))

        movies.add(MovieEntity(
                "m05",
                "Cold Pursuit",
                "Quiet family man and hard-working snowplow driver Nels is the lifeblood of a glitzy resort town in the Rocky Mountains because he is the one who keeps the winter roads clear. He and his wife live in a comfortable cabin away from the tourists. The town has just awarded him \"Citizen of the Year.\" But Nels has to leave his quiet mountain life when his son is murdered by a powerful drug lord.",
                5,
                R.drawable.poster_cold_persuit
        ))

        movies.add(MovieEntity(
                "m06",
                "Creed II",
                "Years after Adonis Creed made a name for himself under Rocky Balboa's mentorship, the young boxer becomes the Heavyweight Champion of the World. While life is good with that victory and his marriage to Bianca, trouble comes to Philadelphia when Ivan Drago, the Russian boxer who killed Adonis' father, Apollo, arrives with his son, Viktor, to challenge Adonis.",
                5,
                R.drawable.poster_creed
        ))

        movies.add(MovieEntity(
                "m07",
                "Fantastic Beasts: The Crimes of Grindelwald",
                "In an effort to thwart Grindelwald's plans of raising pure-blood wizards to rule over all non-magical beings, Albus Dumbledore enlists his former student Newt Scamander, who agrees to help, though he's unaware of the dangers that lie ahead. Lines are drawn as love and loyalty are tested, even among the truest friends and family, in an increasingly divided wizarding world.",
                5,
                R.drawable.poster_crimes
        ))

        movies.add(MovieEntity(
                "m08",
                "Glass",
                "After pursuing Kevin Wendell Crumb and the multiple identities that reside within, David Dunn finds himself locked in a mental hospital alongside his archenemy, Elijah Price. The trio must now contend with a psychiatrist, who is out to prove they do not actually possess superhuman abilities.",
                5,
                R.drawable.poster_glass
        ))

        movies.add(MovieEntity(
                "m09",
                "How to Train Your Dragon: The Hidden World ",
                "As Hiccup fulfills his dream of creating a peaceful dragon utopia, Toothless' discovery of an untamed, elusive mate draws the Night Fury away. When danger mounts at home and Hiccup's reign as village chief is tested, both dragon and rider must make impossible decisions to save their kind.",
                5,
                R.drawable.poster_how_to_train
        ))

        movies.add(MovieEntity(
                "m10",
                "Avengers: Infinity War",
                "As the Avengers and their allies have continued to protect the world from threats too large for any one hero to handle, a new danger has emerged from the cosmic shadows: Thanos. A despot of intergalactic infamy, his goal is to collect all six Infinity Stones, artifacts of unimaginable power, and use them to inflict his twisted will on all of reality.",
                5,
                R.drawable.poster_infinity_war
        ))

        return movies
    }

    fun setTvshow(): List<MovieEntity>{
        val tvShow =ArrayList<MovieEntity>()

        tvShow.add(MovieEntity(
                "t01",
                "Arrow",
                "Oliver Queen and his father are lost at sea when their luxury yacht sinks, apparently in a storm. His father dies, but Oliver survives for five years on an uncharted island and eventually returns home. But he wasn't alone on the island where he learned not only how to fight and survive but also of his father's corruption and unscrupulous business dealings. He returns to civilization a changed man, determined to put things right.",
                3,
                R.drawable.poster_arrow
        ))

        tvShow.add(MovieEntity(
                "t02",
                "Doom Patrol",
                "A re-imagining of one of DC's most beloved group of outcast Super Heroes: Robotman, Negative Man, Elasti-Girl and Crazy Jane, led by modern-day mad scientist Dr. Niles Caulder (The Chief). The Doom Patrol's members each suffered horrible accidents that gave them superhuman abilities - but also left them scarred and disfigured. ",
                3,
                R.drawable.poster_doom_patrol
        ))

        tvShow.add(MovieEntity(
                "t03",
                "Dragon Ball",
                "What starts off as a bizarre re-telling of the Chinese legend \"Journey to the West\" quickly transforms into pure madness. On a twisted version of Earth, the ridiculously strong child-fighter Son Gokû is joined by several companions in the quest for the seven \"dragon balls\", which, when assembled, will summon the Grand Dragon, who will grant the bearer of the balls one single wish. ",
                4,
                R.drawable.poster_dragon_ball
        ))

        tvShow.add(MovieEntity(
                "t04",
                "Fairy Tail",
                "Lucy, a 17 year old girl, sets out on journey to become a full-fledged wizard and joins the strongest and most (in) famous guild FAIRY TAIL where she meets Natsu, Happy, Gray and Erza, who treat her more like family than friends.",
                4,
                R.drawable.poster_fairytail
        ))

        tvShow.add(MovieEntity(
                "t05",
                "Family Guy",
                "Sick, twisted and politically incorrect, the animated series features the adventures of the Griffin family. Endearingly ignorant Peter and his stay-at-home wife Lois reside in Quahog, R.I., and have three kids.",
                4,
                R.drawable.poster_family_guy
        ))

        tvShow.add(MovieEntity(
                "t06",
                "Flash",
                "Barry Allen is a Central City police forensic scientist with a reasonably happy life, despite the childhood trauma of a mysterious red and yellow lightning killing his mother and framing his father. All that changes when a massive particle accelerator accident leads to Barry being struck by lightning in his lab.",
                3,
                R.drawable.poster_flash
        ))

        tvShow.add(MovieEntity(
                "t07",
                "Game of Thrones",
                "In the mythical continent of Westeros, several powerful families fight for control of the Seven Kingdoms. As conflict erupts in the kingdoms of men, an ancient enemy rises once again to threaten them all. Meanwhile, the last heirs of a recently usurped dynasty plot to take back their homeland from across the Narrow Sea.",
                5,
                R.drawable.poster_god
        ))

        tvShow.add(MovieEntity(
                "t08",
                "Gotham",
                "In crime ridden Gotham City, Thomas and Martha Wayne are murdered before young Bruce Wayne's eyes. Although Gotham City Police Department detectives, James Gordon, and his cynical partner, Harvey Bullock, seem to solace's the case quickly, things are not so simple. Inspired by Bruce's traumatized desire for justice, Gordon vows to find it amid Gotham's corruption.",
                3,
                R.drawable.poster_gotham
        ))

        tvShow.add(MovieEntity(
                "t09",
                "Grey Anatomy",
                "A medical based drama centered around Meredith Grey, an aspiring surgeon and daughter of one of the best surgeons, Dr. Ellis Grey. Throughout the series, Meredith goes through professional and personal challenges along with fellow surgeons at Seattle Grace Hospital.",
                3,
                R.drawable.poster_grey_anatomy
        ))

        tvShow.add(MovieEntity(
                "t10",
                "Hanna",
                "In equal parts high-concept thriller and coming-of-age drama, HANNA follows the journey of an extraordinary young girl raised in the forest, as she evades the relentless pursuit of an off-book CIA agent and tries to unearth the truth behind who she is.",
                3,
                R.drawable.poster_hanna
        ))

        return tvShow
    }
}