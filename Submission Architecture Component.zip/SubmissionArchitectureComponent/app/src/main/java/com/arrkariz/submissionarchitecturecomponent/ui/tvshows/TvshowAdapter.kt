package com.arrkariz.submissionarchitecturecomponent.ui.tvshows

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.arrkariz.submissionarchitecturecomponent.R
import com.arrkariz.submissionarchitecturecomponent.databinding.ItemsRowBinding
import com.arrkariz.submissionarchitecturecomponent.entity.MovieEntity
import com.arrkariz.submissionarchitecturecomponent.ui.detail.DetailActivity
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions


class TvshowAdapter : RecyclerView.Adapter<TvshowAdapter.TvshowViewHolder>() {
    private var listTvshow = ArrayList<MovieEntity>()

    fun setTvshow(tvShow: List<MovieEntity>?) {
        if (tvShow == null) return
        this.listTvshow.clear()
        this.listTvshow.addAll(tvShow)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TvshowViewHolder {
        val itemsBinding =  ItemsRowBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return TvshowViewHolder(itemsBinding)
    }

    override fun onBindViewHolder(holder: TvshowViewHolder, position: Int) {
        val tvShow = listTvshow[position]
        holder.bind(tvShow)
    }

    override fun getItemCount(): Int = listTvshow.size


    class TvshowViewHolder(private val binding: ItemsRowBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(tvShow: MovieEntity) {
            with(binding) {
                tvItemTitle.text = tvShow.title
                tvItemDesc.text = tvShow.desc
                tvRating.text = tvShow.rating.toString()
                itemView.setOnClickListener {
                    val intent = Intent(itemView.context, DetailActivity::class.java)
                    intent.putExtra(DetailActivity.EXTRA_ID, tvShow.movieId)
                    intent.putExtra(DetailActivity.EXTRA_TITLE, tvShow.title)
                    intent.putExtra(DetailActivity.EXTRA_RATING, tvShow.rating)
                    intent.putExtra(DetailActivity.EXTRA_DESC, tvShow.desc)
                    itemView.context.startActivity(intent)
                }
                Glide.with(itemView.context)
                        .load(tvShow.imagePath)
                        .apply(RequestOptions.placeholderOf(R.drawable.ic_loading)
                                .error(R.drawable.ic_baseline_broken_image_24))
                        .into(imgPoster)
            }
        }
    }
}